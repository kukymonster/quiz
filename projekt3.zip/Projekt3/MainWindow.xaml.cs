﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
namespace Projekt3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Quiz> kerdesek = new List<Quiz>();
        List<Quiz> aktív = new List<Quiz>();
        List<string> temakSzama = new List<string>();
        Random rnd = new Random();
        string[] sor = File.ReadAllLines("kerdesek.txt");
        int counter = 0;
        public MainWindow()
        {
            InitializeComponent();
            KerdesekFeltoltese();
            Kezdes();
        }
        //Pap Robi része(Kezdés)
        private void Kezdes()
        {
            temak.IsEnabled = true;
            teszt.Visibility = Visibility.Visible;
            kiertekeles.Content = "Kezdés";
            elerhetoKerdesek.Content = $"{counter + 1}/10";
            kiertekeles.Visibility = Visibility.Visible;
            elerhetoKerdesek.Visibility = Visibility.Hidden;
            valasz1.Visibility = Visibility.Hidden;
            valasz2.Visibility = Visibility.Hidden;
            valasz3.Visibility = Visibility.Hidden;
            valasz4.Visibility = Visibility.Hidden;
            kerdes.Visibility = Visibility.Hidden;
            bal.Visibility = Visibility.Hidden;
            jobb.Visibility = Visibility.Hidden;
        }
        //Szép-Szabó része(kérdések feltöltése)
        private void KerdesekFeltoltese()
        {
            for (int i = 0; i < sor.Length; i++)
            {
                kerdesek.Add(new Quiz(0, sor[i]));
            }
            for (int i = 0; i < kerdesek.Count; i++)
            {
                if (!temak.Items.Contains(kerdesek[i].Topic))
                {
                    temak.Items.Add(kerdesek[i].Topic);
                    temakSzama.Add(kerdesek[i].Topic);
                }
            }
        }
        //Pap Robi része(bal és jobb click)
        private void bal_Click(object sender, RoutedEventArgs e)
        {
            if (counter != 0)
                counter--;
            elerhetoKerdesek.Content = $"{counter + 1}/10";
            Frissites();
        }
        private void jobb_Click(object sender, RoutedEventArgs e)
        {
            if(counter + 1 < aktív.Count)
                counter++;
            elerhetoKerdesek.Content = $"{counter + 1}/10";
            Frissites();
        }
        //Pap Robi és Szép-Szabó kollaborációja(kiértékelés)
        private void kiretekeles_Click(object sender, RoutedEventArgs e)
        {
            //Pap Robi része
            if(kiertekeles.Content.ToString() == "Kezdés")
            {
                temak.IsEnabled = false;
                teszt.Visibility = Visibility.Hidden;
                kiertekeles.Content = "Kiértékelés";
                kiertekeles.Visibility = Visibility.Hidden;
                elerhetoKerdesek.Visibility = Visibility.Visible;
                valasz1.Visibility = Visibility.Visible;
                valasz2.Visibility = Visibility.Visible;
                valasz3.Visibility = Visibility.Visible;
                valasz4.Visibility = Visibility.Visible;
                kerdes.Visibility = Visibility.Visible;
                bal.Visibility = Visibility.Visible;
                jobb.Visibility = Visibility.Visible;
                KivalasztottElem();
            }
            //Szép-Szabó része
            else
            {
                int helyesValaszok = 0;
                for (int i = 0; i < aktív.Count; i++)
                {
                    if (int.Parse(aktív[i].Helyes) == aktív[i].jelolt)
                     helyesValaszok++;
                }
                MessageBox.Show($"Kérdések száma: {aktív.Count}\nHelyes válaszok száma: {helyesValaszok}");
                Reset();
            }
        }
        //Szép-Szabó része(ellenőrzés, frissítés, kiválasztott elem)
        private void Ellenorzes()
        {
            int i = 0;
            bool jelolesek = false;
            do
            {
                if (aktív[i].jelolt == 0)
                    jelolesek = true;
                i++;
            } while (jelolesek != true && aktív.Count != i);
            if (jelolesek == true)
                kiertekeles.Visibility = Visibility.Hidden;
            else
                kiertekeles.Visibility = Visibility.Visible;
        }
        private void Frissites()
        {
            kerdes.Text = aktív[counter].Kerdes;
            valasz1.Content = aktív[counter].V1;
            valasz2.Content = aktív[counter].V2;
            valasz3.Content = aktív[counter].V3;
            valasz4.Content = aktív[counter].V4;
            Ellenorzes();
            if (aktív[counter].jelolt == 1)
                valasz1.IsChecked = true;
            else if(aktív[counter].jelolt == 2)
                valasz2.IsChecked = true;
            else if (aktív[counter].jelolt == 3)
                valasz3.IsChecked = true;
            else if (aktív[counter].jelolt == 4)
                valasz4.IsChecked = true;
            else
            {
                valasz1.IsChecked = false;
                valasz2.IsChecked = false;
                valasz3.IsChecked = false;
                valasz4.IsChecked = false;
            }
        }
        private void KivalasztottElem()
        {
            string tema = temak.SelectedItem.ToString();
            for (int i = 0; i < temakSzama.Count; i++)
            {
                while (aktív.Count != 10)
                {
                    int random = rnd.Next(0, kerdesek.Count);
                    if (kerdesek[random].Topic == tema && !aktív.Contains(kerdesek[random]))
                        aktív.Add(kerdesek[random]);
                }
            }
            Frissites();
        }
        //Pap Robi része(a 4 rádiógomb megvalósítása)
        private void valasz1_Checked(object sender, RoutedEventArgs e)
        {
            aktív[counter].jelolt = 1;
            Ellenorzes();
        }
        private void valasz2_Checked(object sender, RoutedEventArgs e)
        {
            aktív[counter].jelolt = 2;
            Ellenorzes();
        }
        private void valasz3_Checked(object sender, RoutedEventArgs e)
        {
            aktív[counter].jelolt = 3;
            Ellenorzes();
        }
        private void valasz4_Checked(object sender, RoutedEventArgs e)
        {
            aktív[counter].jelolt = 4;
            Ellenorzes();
        }
        //Szép-Szabó része(reset)
        private void Reset()
        {
            aktív.Clear();
            kerdesek.Clear();
            temakSzama.Clear();
            temak.Items.Clear();
            counter = 0;
            KerdesekFeltoltese();
            Kezdes();
        }
        //Pap Robi és Szép-Szabó kollab(megint)
        private void credits_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show($"Kérdések összeállítója: Pap Robi\nKinézet megvalósítása: Pap Robi\nProgram fő tervezője: Szép-Szabó Bence\n\n2022 All rights reserved");
        }
    }
    //Pap Robi és Szép-Szabó kollaborációja(class hogyan való megvalósítása)
    class Quiz
    {
        private string kerdes;
        private string topic;
        private string v1;
        private string v2;
        private string v3;
        private string v4;
        private string helyes;
        public int jelolt;
        public Quiz(int jelolt, string sor)
        {
            string[] sorElemi = sor.Split(';');
            kerdes = sorElemi[0];
            topic = sorElemi[1];
            v1 = sorElemi[2];
            v2 = sorElemi[3];
            v3 = sorElemi[4];
            v4 = sorElemi[5];
            helyes = sorElemi[6];
            jelolt = this.jelolt;
        }
        public string Kerdes { get { return kerdes; } }
        public string Topic { get { return topic; } }
        public string V1 { get { return v1; } }
        public string V2 { get { return v2; } }
        public string V3 { get { return v3; } }
        public string V4 { get { return v4; } }
        public string Helyes { get { return helyes; } }
    }
}